const router = require("express").Router();

// Admin routes will be added here

module.exports = router;
